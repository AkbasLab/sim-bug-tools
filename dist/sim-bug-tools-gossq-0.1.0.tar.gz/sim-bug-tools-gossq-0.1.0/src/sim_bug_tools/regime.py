
class Regime:
    def __init__(self):
        return